#!/bin/sh
echo $$ > pid
while true ; do
	sleep 0.1s
done
