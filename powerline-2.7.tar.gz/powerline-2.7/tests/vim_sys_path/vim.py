# vim:fileencoding=utf-8:noet
from __future__ import (unicode_literals, division, absolute_import, print_function)

import tests.modules.vim as vim


globals().update(vim._init())
